

export const GET_PRODUCTS_SUCCESS   = 'getProductsSuccess';
export const GET_PRODUCTS_FAIL   = 'getProductsFail';
