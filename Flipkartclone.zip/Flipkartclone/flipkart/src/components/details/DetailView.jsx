


const DetailView = () => {

    return (
        <div>Hello</div>
    )
}


export default DetailView